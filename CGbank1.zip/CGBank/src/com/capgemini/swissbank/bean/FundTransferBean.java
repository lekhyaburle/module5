package com.capgemini.swissbank.bean;

import java.util.Date;

public class FundTransferBean {
	private int fundId;
	private int accId;
	private int payeeAccId;
	private Date dateOfTransferDate;
	private double transAmount;
	public FundTransferBean(int fundId, int accId, int payeeAccId,
			Date dateOfTransferDate, double transAmount) {
		super();
		this.fundId = fundId;
		this.accId = accId;
		this.payeeAccId = payeeAccId;
		this.dateOfTransferDate = dateOfTransferDate;
		this.transAmount = transAmount;
	}
	public FundTransferBean() {
		super();
	}
	public int getFundId() {
		return fundId;
	}
	public void setFundId(int fundId) {
		this.fundId = fundId;
	}
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public int getPayeeAccId() {
		return payeeAccId;
	}
	public void setPayeeAccId(int payeeAccId) {
		this.payeeAccId = payeeAccId;
	}
	public Date getDateOfTransferDate() {
		return dateOfTransferDate;
	}
	public void setDateOfTransferDate(Date dateOfTransferDate) {
		this.dateOfTransferDate = dateOfTransferDate;
	}
	public double getTransAmount() {
		return transAmount;
	}
	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}
	@Override
	public String toString() {
		return "FundTransferBean [fundId=" + fundId + ", accId=" + accId
				+ ", payeeAccId=" + payeeAccId + ", dateOfTransferDate="
				+ dateOfTransferDate + ", transAmount=" + transAmount + "]";
	}
	

}
