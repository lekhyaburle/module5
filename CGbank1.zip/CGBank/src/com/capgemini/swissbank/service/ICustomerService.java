package com.capgemini.swissbank.service;

import java.util.List;

import com.capgemini.swissbank.bean.PayeeBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;

public interface ICustomerService {
	
	public UserTable validateUser(int userId,String password)throws BankException;
	public List<TransactionBean> viewMiniStatement(int accountId)throws BankException;
	public List<TransactionBean> viewDetailedStatement(int accountId)throws BankException;
	public boolean changePassword(int userId,String oldPassword,String newPassword)throws BankException;
	public boolean changeAddress(int accountId,String address)throws BankException;
	public boolean changePhoneNumber(int accountId,String phoneNumber)throws BankException;
	
	public double inFundTransfer(int accountIdTo,int accountIdFrom,double transactionAmount)throws BankException;
	
	public boolean insertPayee(int accountId,int payeeAccountId,String nickName)throws BankException;
	public double outFundTransfer(int accountId,int payeeAccountId,String transactionPassword,double transactionAmount)throws BankException; 
	
	public int generateCheque(int accountId)throws BankException;
	public String trackStatus(int requisitionId)throws BankException;
	public List<PayeeBean> viewPayee(int accountId)
			throws BankException;
	public boolean updateLockStatus(int accountId)throws BankException;
	
	public boolean validateUser(int userId)throws BankException;
	
	public String[] getSecretQuestion(int userId)throws BankException;
	
	public boolean changePassword(int userId,String newPassword)throws BankException;
}
