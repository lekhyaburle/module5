package com.capgemini.swissbank.dao;

public interface IQueryMapperAdmin {
	public static final String INSERTUSER="insert into user_table(AccountID ,USERID ,LOGINPASSWORD,lockstatus, TYPE) values(?,userid_seq.nextval,?,?,?)";
	public static final String INSERTCUSTOMER="insert into CUSTOMER VALUES(?,?,?,?,?,?)";
	public static final String INSERTACCOUNTMASTER="INSERT INTO ACCOUNT_MASTER VALUES(accountid_seq.nextval,?,?,?)";
	
	public static final String GETACCOUNTID="SELECT accountid_seq.CURRVAL from dual";
	public static final String GETUSERID="SELECT userid_seq.CURRVAL from dual";
	
	
	public static final String VIEWTRANSACTIONDAILY="select  TRANSACTIONID, TRANDESCRIPTION, DATEOFTRANSACTION, TRANSACTIONTYPE, TRANAMOUNT, ACCOUNTID from TRANSACTION where DATEOFTRANSACTION=current_date order by DATEOFTRANSACTION";
	public static final String VIEWTRANSACTIONWEEKLY="select  TRANSACTIONID, TRANDESCRIPTION, DATEOFTRANSACTION, TRANSACTIONTYPE, TRANAMOUNT, ACCOUNTID from TRANSACTION where DATEOFTRANSACTION>=current_date-7 order by DATEOFTRANSACTION";
	public static final String VIEWTRANSACTIONMONTHLY="select  TRANSACTIONID, TRANDESCRIPTION, DATEOFTRANSACTION, TRANSACTIONTYPE, TRANAMOUNT, ACCOUNTID from TRANSACTION where DATEOFTRANSACTION>=current_date-30 order by DATEOFTRANSACTION";
}
